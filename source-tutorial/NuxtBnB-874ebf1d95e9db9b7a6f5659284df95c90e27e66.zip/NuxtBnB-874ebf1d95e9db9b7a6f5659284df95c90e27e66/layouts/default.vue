<template>
<div>
    <header style="background-color:#eee;">
        <nuxt-link to="/">Home</nuxt-link>
    </header>
    <nuxt/>
</div>
</template>